package com.demo.cloudGateway.mar28cloud_ProductService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mar28cloudProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mar28cloudProductServiceApplication.class, args);
	}

}
