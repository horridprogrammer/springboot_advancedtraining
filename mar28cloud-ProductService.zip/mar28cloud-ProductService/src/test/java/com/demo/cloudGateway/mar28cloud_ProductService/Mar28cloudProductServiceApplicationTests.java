package com.demo.cloudGateway.mar28cloud_ProductService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mar28cloudProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
