package com.demo.cloudGateway.mar28cloud_ApiGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mar28cloudApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mar28cloudApiGatewayApplication.class, args);
	}

}
