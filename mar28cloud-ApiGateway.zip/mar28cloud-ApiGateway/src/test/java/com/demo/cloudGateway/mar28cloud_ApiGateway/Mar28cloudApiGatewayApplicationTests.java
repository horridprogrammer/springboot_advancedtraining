package com.demo.cloudGateway.mar28cloud_ApiGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mar28cloudApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
