package com.demo.loadBalancer.mar28cloud_loadBalancer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class Mar28cloudLoadBalancerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mar28cloudLoadBalancerApplication.class, args);
		ConfigurableApplicationContext ctx = new SpringApplicationBuilder(Mar28cloudLoadBalancerApplication.class)
		          .web(WebApplicationType.NONE)
		          .run(args);

		        WebClient loadBalancedClient = ctx.getBean(WebClient.Builder.class).build();

		        for(int i = 1; i <= 10; i++) {
		            String response =
		              loadBalancedClient.get().uri("http://localhost:8081/Product")
		                .retrieve().toEntity(String.class)
		                .block().getBody();
		            System.out.println(response);
	}
	}

}
