package com.demo.loadBalancer.mar28cloud_loadBalancer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mar28cloudLoadBalancerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mar28cloudLoadBalancerApplication.class, args);
	}

}
