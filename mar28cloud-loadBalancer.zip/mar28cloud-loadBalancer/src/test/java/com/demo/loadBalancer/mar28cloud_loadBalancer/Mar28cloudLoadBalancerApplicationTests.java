package com.demo.loadBalancer.mar28cloud_loadBalancer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mar28cloudLoadBalancerApplicationTests {

	@Test
	void contextLoads() {
	}

}
