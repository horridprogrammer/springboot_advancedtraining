package com.demo.cloudGateway.mar28cloud_OrderService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mar28cloudOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mar28cloudOrderServiceApplication.class, args);
	}

}
