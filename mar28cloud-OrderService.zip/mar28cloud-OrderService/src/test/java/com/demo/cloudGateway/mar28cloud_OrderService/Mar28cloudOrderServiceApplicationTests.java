package com.demo.cloudGateway.mar28cloud_OrderService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mar28cloudOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
