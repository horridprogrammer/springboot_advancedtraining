package com.demo.cloudGateway.mar28cloud_CustomerService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mar28cloudCustomerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
