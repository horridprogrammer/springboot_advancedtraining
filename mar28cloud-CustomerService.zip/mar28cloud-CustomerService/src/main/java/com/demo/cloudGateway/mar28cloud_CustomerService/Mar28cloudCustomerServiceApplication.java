package com.demo.cloudGateway.mar28cloud_CustomerService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mar28cloudCustomerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mar28cloudCustomerServiceApplication.class, args);
	}

}
