package com.demo.circuitBreaker.mar28cloud_circuitBreaker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mar28cloudCircuitBreakerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mar28cloudCircuitBreakerApplication.class, args);
	}

}
