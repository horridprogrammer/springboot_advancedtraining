package com.demo.circuitBreaker.mar28cloud_circuitBreaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mar28cloudCircuitBreakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
